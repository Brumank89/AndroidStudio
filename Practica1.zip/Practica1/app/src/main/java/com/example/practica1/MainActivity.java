package com.example.practica1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        EditText editTemperature = findViewById(R.id.temperature);
        TextView txtGrade = findViewById(R.id.txt_degrees);
        Button boton = findViewById(R.id.btn_convert);

        boton.setOnClickListener(v -> {
            String fahrenheit = editTemperature.getText().toString();
            float value = Integer.parseInt(fahrenheit);
            if (!fahrenheit.isEmpty()) {
                float result = (value - 32) / 1.8f;
                String celsius = Float.toString(result);
                txtGrade.setText(celsius);
            } else {
                Toast.makeText(this,"Debes ingresar la temperatura a convertir",
                        Toast.LENGTH_SHORT).show();
            }

        });
    }
}